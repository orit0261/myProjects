import logging

logging.getLogger('code-value_cipher').setLevel(logging.WARNING)